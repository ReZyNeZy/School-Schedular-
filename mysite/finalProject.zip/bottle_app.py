
# A very simple Bottle Hello World app for you to get started with...
from bottle import default_app, route, template, post

from final_project import *

@route('/')
def hello_world():
    return 'Hello from Bottle!'

@route('/bmi')
def bmi():

    return template("bmi.html")



@post('/calculateBmi')
def calculateBmi():

    return template("bmiResult.html")

@route('/mToKm')
def milesToKilometers():

    return template("milesToKilometers.html")

application = default_app()


@route('/kToM')

def kilometersToMiles():

    return template("kilometersToMiles.html")

@post('/convertMtoK')

def resultMTK():

    return template("resultMTK.html")

@post('/convertKtoM')

def resultKTM():

    return template("resultKTM.html")
